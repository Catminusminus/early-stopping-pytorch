# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['early_stopping_pytorch']

package_data = \
{'': ['*']}

install_requires = \
['torch>=1.8.1,<2.0.0']

setup_kwargs = {
    'name': 'early-stopping-pytorch',
    'version': '0.0.0',
    'description': 'Early stopping for PyTorch',
    'long_description': None,
    'author': 'Catminusminus',
    'author_email': 'getomya@svk.jp',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
